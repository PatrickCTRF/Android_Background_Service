package com.example.patrick.background;

import android.app.Activity;
import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Fragment;

import android.view.Menu;
import android.view.View;

public class MainActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //getMenuInflater().inflate(R.menu.activity_main, menu);
        return false;//Estou retornando False para o menu nao ser exibido. VErificar se vai dar certo!!
    }

    // Método que dará início ao servico de background.
    public void startService(View view) {
        startService(new Intent(getBaseContext(), MyService.class));//Como aki eu invoco um metodo q nao foi implementado??? Ele pertence a Context.
    }

    // Metodo que parara o servico
    public void stopService(View view) {
        stopService(new Intent(getBaseContext(), MyService.class));
    }
}

/*public class MainActivity extends Activity {
    Intent mServiceIntent = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mServiceIntent = new Intent(getActivity(), RSSPullService.class);//supus que getActivity pertencia à classe Fragment. Mas nao funcionou pois nao era static.
        mServiceIntent.setData(Uri.parse(dataUrl));

        getActivity().startService(mServiceIntent);// Esse getActivity() nao é reconhecido de jeito algum. Nos exemplos ele vem sempre sozinho
    }




}*/


/*


    // use this to start and trigger a service
    Intent i= new Intent(Context.class, MyService.class);// É válido eu passar as classes desta forma?
// potentially add data to the intent
    i.putExtra("KEY1", "Value to be used by the service");
    Context.startService(i);*/